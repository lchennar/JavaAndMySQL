package Eight_Puzzle;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

import static java.lang.System.exit;

public class AStarAlgo {
    static int totalNoOfNodes = 1,depth = 0;
    public static PriorityQueue<Node> possibleStateQueue = new PriorityQueue<Node>();
    public static ArrayList<Node> nodesExplored = new ArrayList<>();

public static void main(String args[]){
    int choice =1 , isSolutionPresent=-1;

    Scanner scanner = new Scanner(System.in);

    int[][] inputState = new int[3][3];
    int[][] goalState = new int[3][3];

    System.out.println("Enter Initial state ");
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            inputState[i][j]= scanner.nextInt();

        }
    }

    System.out.println("Enter Goal state ");
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            goalState[i][j]= scanner.nextInt();

        }
    }

/*     int[][] inputState = {{0,1,3},{4,2,5},{7,8,6}};
     int[][] goalState = {{1,2,3},{4,5,6},{7,8,0}};*/

    System.out.println("Please select a heuristic function for implementing A* Algorithm:\n1) Misplaced Tile \n2) Manhattan Distance:");
    choice = scanner.nextInt();
    if(choice<=0 || choice>2) {
        System.err.println("Please enter a correct choice: '1' or '2' ");
        exit(1);
    } else {
        System.out.println("Input state is :");
        printState(inputState);
        System.out.println("Search starts - :");
        isSolutionPresent = gameSearch(inputState,choice,goalState);

    }
    if(isSolutionPresent == 0){
        System.out.println("Goal state reached!");

    }
    else{
        System.out.println("No solution found");
    }
    System.out.println("Total Number of child Nodes Generated : "+totalNoOfNodes);
    System.out.println("Total number of nodes explored to achieve goal state :"+ nodesExplored.size());
    System.out.println("The depth level is : " + depth);
    System.out.println("------------------------------------------------------------------");
}


    public static int gameSearch(int[][] gameStartState, int heuristicFunctionChoice, int[][] goalState ){

        possibleStateQueue.add(new Node(gameStartState,0, calculateHeuristicValue(gameStartState,goalState,heuristicFunctionChoice)));
        //nodesExplored.add(new Node(gameStartState,0, calculateHeuristicValue(gameStartState,goalState,heuristicFunctionChoice)));
        while(true) {
            if(possibleStateQueue.isEmpty()){
                return -1;
            }

            Node currentGameNode = possibleStateQueue.peek();


            //System.out.println(" g(n)="+currentGameNode.getgOfN()+" and h(n)="+currentGameNode.getHeuristicValue()+" and f(n)="+currentGameNode.getFOfN()+"...");
            printState(currentGameNode.getState());
            possibleStateQueue.remove();

            if(isGoalStateReached(currentGameNode.getState(), goalState)) {
                depth = currentGameNode.getgOfN();
                return 0;
            }
            else {
                nodesExplored.add(currentGameNode);

                ArrayList<Node> childNodes = getChildNodes(currentGameNode, heuristicFunctionChoice, goalState);

                if (childNodes.size() == 0) {
                   continue;
                }


                for (Node child : childNodes) {
                    if (!isExploredNode(child) ) { //&& !possibleStateQueue.contains(child)
                        possibleStateQueue.add(child);
                        totalNoOfNodes++;
                    }
                }
            }

        }
    }
    public static void printState(int[][] currentState) {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                System.out.print(currentState[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println();
    }


    public static boolean isGoalStateReached(int[][] currentState, int[][] goalState) {
        for(int row=0; row<3; row++)
            for(int column=0; column<3; column++)
                if(currentState[row][column] != goalState[row][column])
                    return false;
        return true;
    }

    public static int calculateHeuristicValue(int [][] currentGameState, int[][] goalState, int heuristicFunctionChoice){
        int heuristicValue = 0;
        if(heuristicFunctionChoice == 1) {//Misplaced tiles heuristic
            for (int row = 0; row < 3; row++) {
                for (int column = 0; column < 3; column++) {
                    if (currentGameState[row][column] !=0 && currentGameState[row][column] != goalState[row][column])
                        heuristicValue++;
                }
            }
        }
        else{//Manhattan distance heuristic
            for(int currentGameStateRow=0; currentGameStateRow<3; currentGameStateRow++){
                for(int currentGameStateColumn=0; currentGameStateColumn<3; currentGameStateColumn++) {
                    int currentTile = currentGameState[currentGameStateRow][currentGameStateColumn];
                    for (int goalStateRow = 0; goalStateRow < 3; goalStateRow++)
                        for (int goalStateColumn = 0; goalStateColumn < 3; goalStateColumn++) {
                            if (currentTile !=0 && goalState[goalStateRow][goalStateColumn] == currentTile ) {
                                heuristicValue += Math.abs(goalStateRow - currentGameStateRow) + Math.abs(goalStateColumn - currentGameStateColumn);
                            }
                        }
                }
            }


        }
        return heuristicValue;
    }

    public static Node leftMove(Node currentNode,int[][] goalState, int emptyTileRowIndex, int emptyTileColumnIndex, int heuristicFunction ){
        int [][] currentState = currentNode.getState();
        int [][] possibleChildState = new int[3][3];
        for(int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                possibleChildState[row][column] = currentState[row][column];
            }
        }
        int temp = possibleChildState[emptyTileRowIndex][emptyTileColumnIndex];
        possibleChildState[emptyTileRowIndex][emptyTileColumnIndex] = possibleChildState[emptyTileRowIndex-1][emptyTileColumnIndex];
        possibleChildState[emptyTileRowIndex-1][emptyTileColumnIndex] = temp;
        return new Node(possibleChildState,currentNode.getgOfN()+1, calculateHeuristicValue(possibleChildState,goalState,heuristicFunction));
    }

    public static Node rightMove(Node currentNode,int[][] goalState, int emptyTileRowIndex, int emptyTileColumnIndex, int heuristicFunction ){
        int [][] currentState = currentNode.getState();
        int [][] possibleChildState = new int[3][3];
        for(int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                possibleChildState[row][column] = currentState[row][column];
            }
        }
        int temp = possibleChildState[emptyTileRowIndex][emptyTileColumnIndex];
        possibleChildState[emptyTileRowIndex][emptyTileColumnIndex] = possibleChildState[emptyTileRowIndex+1][emptyTileColumnIndex];
        possibleChildState[emptyTileRowIndex+1][emptyTileColumnIndex] = temp;
        return new Node(possibleChildState,currentNode.getgOfN()+1, calculateHeuristicValue(possibleChildState,goalState,heuristicFunction));
    }

    public static Node upMove(Node currentNode,int[][] goalState, int emptyTileRowIndex, int emptyTileColumnIndex, int heuristicFunction ){
        int [][] currentState = currentNode.getState();
        int [][] possibleChildState = new int[3][3];
        for(int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                possibleChildState[row][column] = currentState[row][column];
            }
        }
        int temp = possibleChildState[emptyTileRowIndex][emptyTileColumnIndex];
        possibleChildState[emptyTileRowIndex][emptyTileColumnIndex] = possibleChildState[emptyTileRowIndex][emptyTileColumnIndex-1];
        possibleChildState[emptyTileRowIndex][emptyTileColumnIndex-1] = temp;
        return new Node(possibleChildState,currentNode.getgOfN()+1, calculateHeuristicValue(possibleChildState,goalState,heuristicFunction));
    }
    public static Node downMove(Node currentNode,int[][] goalState, int emptyTileRowIndex, int emptyTileColumnIndex, int heuristicFunction ){
        int [][] currentState = currentNode.getState();
        int [][] possibleChildState = new int[3][3];
        for(int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                possibleChildState[row][column] = currentState[row][column];
            }
        }
        int temp = possibleChildState[emptyTileRowIndex][emptyTileColumnIndex];
        possibleChildState[emptyTileRowIndex][emptyTileColumnIndex] = possibleChildState[emptyTileRowIndex][emptyTileColumnIndex+1];
        possibleChildState[emptyTileRowIndex][emptyTileColumnIndex+1] = temp;
        return new Node(possibleChildState,currentNode.getgOfN()+1, calculateHeuristicValue(possibleChildState,goalState,heuristicFunction));
    }

    public static ArrayList<Node> getChildNodes(Node currentNode, int heuristicFunction, int[][] goalState) {

        ArrayList<Node> childNodes = new ArrayList<>();
        int[][] currentGameState = currentNode.getState();
        int gOfN = currentNode.getgOfN();
        int emptyTileColumnIndex = -1;
        int emptyTileRowIndex = -1;
        for(int row=0; row<3; row++) {
            for(int column=0; column<3; column++) {
                if(currentGameState[row][column]==0) {
                    emptyTileColumnIndex = row;
                    emptyTileRowIndex = column;
                }
            }
        }

        if(emptyTileColumnIndex-1 >=0) {  //can left move
            childNodes.add(leftMove(currentNode,goalState,emptyTileColumnIndex,emptyTileRowIndex,heuristicFunction));
        }
        if(emptyTileColumnIndex+1 < 3) {  // can right move

            childNodes.add(rightMove(currentNode,goalState,emptyTileColumnIndex,emptyTileRowIndex,heuristicFunction));
        }
        if(emptyTileRowIndex-1 >=0) {  // Can move UP

            childNodes.add(upMove(currentNode,goalState,emptyTileColumnIndex,emptyTileRowIndex,heuristicFunction));
        }
        if(emptyTileRowIndex+1 < 3) {  // Can move down

            childNodes.add(downMove(currentNode,goalState,emptyTileColumnIndex,emptyTileRowIndex,heuristicFunction));
        }

        return childNodes;
    }


    public static boolean isExploredNode(Node currentNode) {
        int[][] currentChild = currentNode.getState();
        for (Node exploredNode : nodesExplored) {
            int[][] exploredNodeState = exploredNode.getState();
            boolean isNodePresent = true;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (exploredNodeState[i][j] != currentChild[i][j])
                        isNodePresent = false;
                }
            }
            if (isNodePresent)
                return true;
        }
        return false;

    }
}