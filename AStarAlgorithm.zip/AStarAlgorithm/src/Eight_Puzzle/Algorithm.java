package Eight_Puzzle;

public class Algorithm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
