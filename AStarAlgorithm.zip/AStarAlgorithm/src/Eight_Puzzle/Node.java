package Eight_Puzzle;
public class Node implements Comparable<Node>{
    private int[][] state;
    private int gOfN;  // cost
    private int heuristicValue;  // heuristic distance

    public Node(int[][] state, int gOfN, int heuristicValue) {
        this.state = state;
        this.gOfN = gOfN;
        this.heuristicValue = heuristicValue;
    }

    public int[][] getState() {
        return state;
    }
    public int getgOfN() {
        return gOfN;
    }
    public int getHeuristicValue() {
        return heuristicValue;
    }
    public int getFOfN() {
        return (gOfN + heuristicValue);
    }

    @Override
    public int compareTo(Node other)
    {
        if (getFOfN() != other.getFOfN())
            return Integer.compare(getFOfN(), other.getFOfN());
        else
            return Integer.compare(heuristicValue, other.heuristicValue);
    }

}
