-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: unccfall2018dbproject.cukyi9tv8fg2.us-east-2.rds.amazonaws.com    Database: unccfall2018dbproject
-- ------------------------------------------------------
-- Server version	5.7.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Administrator`
--

DROP TABLE IF EXISTS `Administrator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Administrator` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Administrator`
--

LOCK TABLES `Administrator` WRITE;
/*!40000 ALTER TABLE `Administrator` DISABLE KEYS */;
INSERT INTO `Administrator` VALUES ('admin1','catinthehat'),('admin2','thing1'),('admin3','thing2');
/*!40000 ALTER TABLE `Administrator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Company`
--

DROP TABLE IF EXISTS `Company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Company` (
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `adr_line_1` varchar(255) NOT NULL,
  `adr_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Company`
--

LOCK TABLES `Company` WRITE;
/*!40000 ALTER TABLE `Company` DISABLE KEYS */;
INSERT INTO `Company` VALUES ('Allstate','','1-877-810-2920','2775 Sanders Road',NULL,'Northbrook','Illinois','60062'),('Geico','','800-841-3000','1 GEICO Blvd',NULL,'Fredericksburg','Virginia','22412'),('Pegram','contact@pegramonline.com','704-494-9495','9010 Glenwater Dr','103','Charlotte','North Carolina','28262'),('Progressive','','1-855-347-3939','6300 Wilson Mills Road',NULL,'Mayfield Village','Ohio','44143'),('State Farm','','855-733-7333','One State Farm Plaza',NULL,'Bloomington','Illinois','61710');
/*!40000 ALTER TABLE `Company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Dental_Insurance_Policy`
--

DROP TABLE IF EXISTS `Dental_Insurance_Policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dental_Insurance_Policy` (
  `policy_id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `premium_rate_monthly` double NOT NULL,
  `basic_major_maximum` double DEFAULT NULL,
  `orthodontic_maximum` double DEFAULT NULL,
  `diagnostic_preventive_co_insurance` double DEFAULT NULL,
  `basic_co_insurance` double DEFAULT NULL,
  `major_co_insurance` double DEFAULT NULL,
  `orthodontic_co_insurance` double DEFAULT NULL,
  `basic_major_deductible` double DEFAULT NULL,
  `orthodontic_deductible` double DEFAULT NULL,
  PRIMARY KEY (`policy_id`,`company`),
  KEY `company` (`company`),
  CONSTRAINT `Dental_Insurance_Policy_ibfk_1` FOREIGN KEY (`company`) REFERENCES `Company` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Dental_Insurance_Policy`
--

LOCK TABLES `Dental_Insurance_Policy` WRITE;
/*!40000 ALTER TABLE `Dental_Insurance_Policy` DISABLE KEYS */;
INSERT INTO `Dental_Insurance_Policy` VALUES (1,'Pegram',25,220,10000,10000,15000,12000,16000,20000,12000),(2,'Geico',30,310,20000,12000,16500,12500,16000,20000,12500),(3,'Allstate',50,550,50000,12000,17000,14000,18000,25000,14000),(4,'Progressive',35,340,10000,15000,17000,15000,20000,22000,25000),(5,'State Farm',60,650,60000,17000,18000,16000,22000,23000,70000);
/*!40000 ALTER TABLE `Dental_Insurance_Policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Dependent`
--

DROP TABLE IF EXISTS `Dependent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dependent` (
  `dependent_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `medical_id` int(11) NOT NULL,
  `ssn` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` char(1) NOT NULL,
  PRIMARY KEY (`dependent_id`),
  KEY `user_id` (`user_id`),
  KEY `medical_id` (`medical_id`),
  CONSTRAINT `Dependent_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`username`),
  CONSTRAINT `Dependent_ibfk_2` FOREIGN KEY (`medical_id`) REFERENCES `Medical_History` (`medical_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Dependent`
--

LOCK TABLES `Dependent` WRITE;
/*!40000 ALTER TABLE `Dependent` DISABLE KEYS */;
INSERT INTO `Dependent` VALUES (1,'ladiesman217',1,'098365432','Maria','Lopez','Child','1999-12-12','f'),(2,'ascott',3,'008765432','Peter','Nelson','Child','2000-11-02','m'),(3,'aJackson',5,'098705432','Rachel','Thomas','Child','2001-10-12','m'),(4,'aRobonson',7,'098761432','Stuart','Thomson','Child','2001-09-02','f'),(5,'aRobonson',8,'098762432','Victoria','Lewis','Child','2002-08-12','m'),(6,'elmosworld',9,'098735432','Vincent','Lee','Child','2003-07-02','m'),(7,'sliam',12,'098765532','Maria','Nelson','Child','2004-06-13','f'),(8,'lebeouf',13,'098165432','Michael','Thomas','Child','2004-05-14','m'),(9,'lebeouf',14,'098265432','Stuart','Thomas','Child','2000-04-15','m'),(10,'rosie',15,'098365432','Peter','Lopez','Child','1995-03-16','m'),(11,'erobin',16,'098465432','Vincent','Bay','Child','1994-02-17','m'),(12,'ctaylor',17,'098565432','Stuart','Thomson','Child','2008-01-18','m'),(13,'bJohnson',18,'098665432','Victoria','Lee','Child','2005-12-19','m'),(14,'mitchell',19,'098765432','Rachel','Bay','Child','2000-11-20','f'),(15,'therock',20,'098865432','Peter','Lee','Child','2002-10-21','m'),(16,'elmosworld',21,'098965432','Michael','Nelson','Child','2001-09-22','m'),(17,'jacksepticeye',22,'098765431','Michael','Bay','Child','1994-08-23','m');
/*!40000 ALTER TABLE `Dependent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Homeowners_History`
--

DROP TABLE IF EXISTS `Homeowners_History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Homeowners_History` (
  `home_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `adr_line_1` varchar(255) NOT NULL,
  `adr_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `current_value` double NOT NULL,
  `year_built` int(11) NOT NULL,
  `sq_ft` double NOT NULL,
  `home_type` varchar(255) NOT NULL,
  `stories` int(11) NOT NULL,
  `construction_type` varchar(255) NOT NULL,
  `roof_type` varchar(255) NOT NULL,
  `occupany` varchar(255) NOT NULL,
  `damage` tinyint(1) NOT NULL,
  `detatched_structures` tinyint(1) NOT NULL,
  `business` tinyint(1) NOT NULL,
  `deadbolt` tinyint(1) NOT NULL,
  `fire_extinguisher` tinyint(1) NOT NULL,
  `sprinkler_system` tinyint(1) NOT NULL,
  `fire_alarm` tinyint(1) NOT NULL,
  `burglar_alarm` tinyint(1) NOT NULL,
  `loses_5_years` tinyint(1) NOT NULL,
  `replacement_cost` double NOT NULL,
  PRIMARY KEY (`home_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Homeowners_History_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Homeowners_History`
--

LOCK TABLES `Homeowners_History` WRITE;
/*!40000 ALTER TABLE `Homeowners_History` DISABLE KEYS */;
INSERT INTO `Homeowners_History` VALUES (1,'hela','1834  Ingram Road',NULL,'Greensboro','North Carolina','27406',60000,2009,1500,'RoomingHouse',2,'Concrete','Concrete','4',0,0,0,0,1,1,1,1,0,0),(2,'erobin','123 Freedom Street',NULL,'Morrisville','North Carolina','27541',45000,2010,1300,'RoomingHouse',2,'Wooden','Wooden','2',1,0,0,0,1,1,1,1,0,5000),(3,'ctaylor','123 Shanon Street',NULL,'New York','New York','11111',65000,2011,1400,'RoomingHouse',2,'Concrete','Wooden','4',1,0,0,0,1,1,1,1,0,0),(4,'bJohnson','453 Royal Sreet',NULL,'Raleigh','North Carolina','28241',70000,2005,1400,'RoomingHouse',3,'Concrete','Concrete','3',1,1,1,0,1,1,1,1,0,1000),(5,'parkeranna','123 Sesame Street',NULL,'New York','New York','11111',73000,2015,1450,'CottageHouse',4,'Wooden','Wooden','6',1,0,0,0,1,1,1,1,0,800),(6,'mitchell','123 Barton Street',NULL,'Cary','North Carolina','25711',49000,2006,900,'RoomingHouse',1,'Concrete','Wooden','4',0,0,1,1,1,1,1,1,0,0),(7,'wrightA','123 University Street',NULL,'Charlotte','North Carolina','28261',75000,2000,1260,'RoomingHouse',4,'Concrete','Concrete','4',1,0,1,0,1,1,1,1,0,1200),(8,'ascott','123 Sesame Street',NULL,'SanFransisco','California','12341',69000,2011,1000,'RoomingHouse',3,'Concrete','Wooden','3',0,0,0,0,1,1,1,1,0,0),(9,'aJackson','University Street',NULL,'Los Angeles','California','18456',880000,2016,1500,'RoomingHouse',4,'Wooden','Wooden','4',1,1,1,0,1,1,1,1,0,800),(10,'aRobonson','123 Sesame Street',NULL,'New York','New York','14561',30000,2000,500,'SingleOcupancy',1,'Concrete','Wooden','2',0,0,1,0,1,1,1,1,0,0);
/*!40000 ALTER TABLE `Homeowners_History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Homeowners_Insurance_Policy`
--

DROP TABLE IF EXISTS `Homeowners_Insurance_Policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Homeowners_Insurance_Policy` (
  `policy_id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `premium_rate_monthly` double NOT NULL,
  `premium_rate_yearly` double NOT NULL,
  `dwelling_coverage` double DEFAULT NULL,
  `other_structures_coverage` double DEFAULT NULL,
  `personal_property_coverage` double DEFAULT NULL,
  `loss_of_use_coverage` double DEFAULT NULL,
  `personal_liability_coverage` double DEFAULT NULL,
  `water_back_up_coverage` double DEFAULT NULL,
  `deductible` double DEFAULT NULL,
  PRIMARY KEY (`policy_id`,`company`),
  KEY `company` (`company`),
  CONSTRAINT `Homeowners_Insurance_Policy_ibfk_1` FOREIGN KEY (`company`) REFERENCES `Company` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Homeowners_Insurance_Policy`
--

LOCK TABLES `Homeowners_Insurance_Policy` WRITE;
/*!40000 ALTER TABLE `Homeowners_Insurance_Policy` DISABLE KEYS */;
INSERT INTO `Homeowners_Insurance_Policy` VALUES (2,'Geico',72,869,1000,2200,25000,1000,26000,1000,30),(3,'Allstate',85,945,1100,2400,26000,1200,25000,1100,35),(4,'Progressive',81,913,1200,2400,26500,1500,27000,1200,40),(5,'State Farm',93,1104,1300,2500,27000,1800,28000,1400,50),(6,'Pegram',100,1100,1400,2600,28000,2000,26000,1500,80),(7,'Allstate',112,1200,1500,2700,30000,2200,25000,1600,85),(8,'Progressive',125,1250,1600,2800,32500,2500,27000,1700,90),(9,'State Farm',140,1300,1700,2900,35000,2800,28000,1800,95);
/*!40000 ALTER TABLE `Homeowners_Insurance_Policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Insurance_Agent`
--

DROP TABLE IF EXISTS `Insurance_Agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Insurance_Agent` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number_cell` varchar(255) DEFAULT NULL,
  `phone_number_work` varchar(255) NOT NULL,
  `adr_line_1` varchar(255) NOT NULL,
  `adr_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  PRIMARY KEY (`username`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `Insurance_Agent_ibfk_1` FOREIGN KEY (`company_name`) REFERENCES `Company` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Insurance_Agent`
--

LOCK TABLES `Insurance_Agent` WRITE;
/*!40000 ALTER TABLE `Insurance_Agent` DISABLE KEYS */;
INSERT INTO `Insurance_Agent` VALUES ('Deep Throat','Watergate','Deep','Throat','mfelt@yahoo.com',NULL,'221-133-4455','234 White House',NULL,'Arlington','Virginia','20124','Progressive'),('Goodman','Good Man','John','Goodman','jgoodman@gmail.com',NULL,'112-233-4455','789 Wallstreet',NULL,'Charlotte','North Carolina','28216','Geico'),('Grace','Grace','Amazing','Grace','amace@yahoo.com',NULL,'113-322-4455','500 Country Road',NULL,'Take Me Home','Virginia','20120','Allstate'),('Hulk','Strongest Avenger','Bruce','Banner','greenman@gmail.com',NULL,'441-122-3355','786 Ragnorok Ln.',NULL,'Houston','Texas','73301','Pegram'),('JD','Scrubs','John','Michael','jd@gmail.com',NULL,'331-122-4455','345 Sacred Heart Blvd.',NULL,'Charlotte','North Carolina','28216','Allstate'),('Kong','King','King','Kong','kiong@hotmail.com',NULL,'551-122-3344','543 Skull Island Dr.',NULL,'Minneapolis','Minnesota','55105','Pegram'),('MJ','Moonwalk','Billy','Jean','mj@gmail.com',NULL,'223-344-5511','542 Woo St.',NULL,'Raleigh','North Carolina','27513','Geico'),('Scoob','Scooby Snacks','Scooby','Doo','ruh-roh@gmail.com',NULL,'442-233-1155','709 Mystery Machine Rd.',NULL,'Charlotte','North Carolina','28216','Progressive'),('Smith','Hugo','Agent','Smith','smith@yahoo.com',NULL,'123-456-7891','123 Work Rd.',NULL,'The Matrix','New Jersey','10101','Geico'),('Steve','Blues Clues','Steve','','steveakidjustlikeyou@yahoo.com',NULL,'553-344-2211','432 Blue’s House',NULL,'Gastonia','North Carolina','28056','Allstate');
/*!40000 ALTER TABLE `Insurance_Agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Medical_History`
--

DROP TABLE IF EXISTS `Medical_History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Medical_History` (
  `medical_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `smoker` tinyint(1) NOT NULL,
  `height_feet` int(11) NOT NULL,
  `height_inches` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`medical_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Medical_History_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Medical_History`
--

LOCK TABLES `Medical_History` WRITE;
/*!40000 ALTER TABLE `Medical_History` DISABLE KEYS */;
INSERT INTO `Medical_History` VALUES (1,'ladiesman217',0,5,9,150,'Dependent'),(2,'wrightA',1,6,2,160,'Customer'),(3,'ascott',0,5,7,150,'Dependent'),(4,'ascott',1,6,2,160,'Customer'),(5,'aJackson',0,5,9,150,'Dependent'),(6,'aRobonson',1,6,2,160,'Customer'),(7,'aRobonson',0,6,2,160,'Dependent'),(8,'aRobonson',1,6,2,160,'Dependent'),(9,'elmosworld',1,6,2,160,'Dependent'),(10,'elmosworld',1,6,2,160,'Customer'),(11,'sliam',1,6,2,160,'Customer'),(12,'sliam',0,6,2,160,'Dependent'),(13,'lebeouf',1,6,2,160,'Dependent'),(14,'lebeouf',0,6,2,160,'Dependent'),(15,'rosie',1,6,2,160,'Dependent'),(16,'erobin',0,6,2,160,'Dependent'),(17,'ctaylor',1,6,2,160,'Dependent'),(18,'bJohnson',1,6,2,160,'Dependent'),(19,'mitchell',1,6,2,160,'Dependent'),(20,'therock',0,6,2,160,'Dependent'),(21,'elmosworld',1,6,2,160,'Dependent'),(22,'jacksepticeye',1,6,2,160,'Dependent');
/*!40000 ALTER TABLE `Medical_History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Medical_Insurance_Policy`
--

DROP TABLE IF EXISTS `Medical_Insurance_Policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Medical_Insurance_Policy` (
  `policy_id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `premium_monthly_rate` double NOT NULL,
  `premium_yearly_rate` double NOT NULL,
  `lifetime_maximum` double DEFAULT NULL,
  `annual_maximum` double DEFAULT NULL,
  `per_injury_or_sickness_maximum` double DEFAULT NULL,
  `annual_maximum_deductable` double DEFAULT NULL,
  `co_pay_shc` double DEFAULT NULL,
  `co_pay_primary_care_specialist` double DEFAULT NULL,
  `co_pay_urgent_care` double DEFAULT NULL,
  `emergency_room_co_pay` double DEFAULT NULL,
  `hospitalization_co_pay` double DEFAULT NULL,
  `co_insurance_in_network` double DEFAULT NULL,
  `co_insurance_out_of_network` double DEFAULT NULL,
  `medical_evacuation` double DEFAULT NULL,
  `repatriation_of_remains` double DEFAULT NULL,
  `eligibility` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`policy_id`,`company`),
  KEY `company` (`company`),
  CONSTRAINT `Medical_Insurance_Policy_ibfk_1` FOREIGN KEY (`company`) REFERENCES `Company` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Medical_Insurance_Policy`
--

LOCK TABLES `Medical_Insurance_Policy` WRITE;
/*!40000 ALTER TABLE `Medical_Insurance_Policy` DISABLE KEYS */;
INSERT INTO `Medical_Insurance_Policy` VALUES (1,'Pegram',39,500,20000,20000,400,500,25,40,40,300,350,400,90,120000,60000,NULL),(2,'Pegram',29,350,15000,21000,300,500,35,50,50,350,500,300,70,50000,50000,NULL),(3,'Pegram',49,550,20000,20000,500,90,15,30,30,250,250,500,90,1000000,1000000,NULL),(4,'Geico',59,650,20000,20000,600,100,35,40,40,300,300,600,90,1100000,1100000,NULL),(5,'Geico',69,730,20000,20000,700,120,25,55,55,500,550,700,90,1200000,1200000,NULL),(6,'AllState',79,800,20000,20000,800,130,40,60,60,600,650,800,90,1500000,1500000,NULL);
/*!40000 ALTER TABLE `Medical_Insurance_Policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Renters_History`
--

DROP TABLE IF EXISTS `Renters_History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Renters_History` (
  `renter_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `adr_line_1` varchar(255) NOT NULL,
  `adr_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `fire_alarm` tinyint(1) NOT NULL,
  `burglar_alarm` tinyint(1) NOT NULL,
  `fire_station_distance` double NOT NULL,
  `fire_hydrant_distance` double NOT NULL,
  `fire_extinguishers` tinyint(1) NOT NULL,
  `smoke_detectors` tinyint(1) NOT NULL,
  `siding` varchar(255) NOT NULL,
  `pets` tinyint(1) NOT NULL,
  `number_units` int(11) NOT NULL,
  `people` int(11) NOT NULL,
  PRIMARY KEY (`renter_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Renters_History_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Renters_History`
--

LOCK TABLES `Renters_History` WRITE;
/*!40000 ALTER TABLE `Renters_History` DISABLE KEYS */;
INSERT INTO `Renters_History` VALUES (1,'ladiesman217','123 Sesame Street',NULL,'New York','New York','11111',1,1,10,9,0,1,'Wooden',0,4,2),(2,'therock','123 Sesame Street',NULL,'New York City','New York','10001',1,0,10,8,1,1,'Wooden',1,4,3),(3,'elmosworld','123 Sesame Street',NULL,'New York City','New York','10001',0,1,15,6,0,1,'Brick',0,3,2),(4,'jacksepticeye','123 Bow Street',NULL,'Boston','Massachusetts','34321',1,1,19,7,1,1,'Wooden',0,2,4),(5,'sliam','123 Quick Street',NULL,'New York','New York','11111',0,0,15,9,0,1,'Wooden',1,3,4),(6,'lebeouf','123 Quriky Street',NULL,'New York','New York','11111',1,1,14,6,0,1,'Brick',1,5,4),(7,'lwhite','123 Boggle Street',NULL,'New York','New York','10011',1,1,13,5,0,1,'Wooden',0,5,5),(8,'rosie','123 Musical Lane',NULL,'Detroit','Michigan','22111',1,0,16,4,0,1,'Brick',1,5,2),(9,'alien','123 Wayne Street',NULL,'New York City','New York','11111',1,1,15,3,0,1,'Wooden',1,4,4),(10,'lopez','123 Sesame Street',NULL,'New York','New York','11111',1,1,10,9,0,1,'Wooden',0,4,4);
/*!40000 ALTER TABLE `Renters_History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Renters_Insurance_Policy`
--

DROP TABLE IF EXISTS `Renters_Insurance_Policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Renters_Insurance_Policy` (
  `policy_id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `premium_rate_monthly` double NOT NULL,
  `premium_rate_yearly` double NOT NULL,
  `personal_property_coverage` double DEFAULT NULL,
  `loss_of_use_coverage` double DEFAULT NULL,
  `physical_loss_computers_coverage` tinyint(1) DEFAULT NULL,
  `personal_liability_coverage` double DEFAULT NULL,
  `medical_liability_coverage` double DEFAULT NULL,
  `personal_injury_coverage` double DEFAULT NULL,
  `deductible` double DEFAULT NULL,
  PRIMARY KEY (`policy_id`,`company`),
  KEY `company` (`company`),
  CONSTRAINT `Renters_Insurance_Policy_ibfk_1` FOREIGN KEY (`company`) REFERENCES `Company` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Renters_Insurance_Policy`
--

LOCK TABLES `Renters_Insurance_Policy` WRITE;
/*!40000 ALTER TABLE `Renters_Insurance_Policy` DISABLE KEYS */;
INSERT INTO `Renters_Insurance_Policy` VALUES (2,'Geico',13,154,1000,1000,0,1000,1500,750,12),(3,'Allstate',18,216,1200,1200,1,1050,1700,1000,15),(4,'Progressive',15,185,1100,1300,1,950,1600,800,14),(5,'State Farm',19,224,1500,1500,0,1200,1800,900,20),(6,'Pegram',20,230,1400,1400,0,1000,1500,750,12),(7,'Pegram',22,236,1500,1200,1,1050,1900,1200,20),(8,'Progressive',25,250,1600,1300,1,1050,1600,800,20),(9,'State Farm',29,270,1700,1800,1,1500,1800,900,25);
/*!40000 ALTER TABLE `Renters_Insurance_Policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `username` varchar(255) NOT NULL,
  `ssn` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number_cell` varchar(255) NOT NULL,
  `phone_number_home` varchar(255) DEFAULT NULL,
  `phone_number_work` varchar(255) DEFAULT NULL,
  `adr_line_1` varchar(255) NOT NULL,
  `adr_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` char(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('aJackson','515611616','Ajack123','Alex','Jackson','Jackson@gmail.com','704-999-9999',NULL,NULL,'University Street',NULL,'Los Angeles','California','18456','1985-05-09','m'),('alien','111191111','sweave','Sigourney','Weaver','sigw@gmail.com','111-888-1111',NULL,NULL,'123 Wayne Street',NULL,'New York City','New York','11111','1949-10-08','f'),('aRobonson','564561667','Arobin234','Andrea','Robinson','Andrea@gmail.com','980-234-7890',NULL,NULL,'123 Sesame Street',NULL,'New York','New York','14561','1975-11-28','m'),('ascott','112111111','Ascott23','Amy','Scott','Scott@gmail.com','234-789-0001',NULL,NULL,'123 Sesame Street',NULL,'SanFransisco','California','12341','1990-06-08','m'),('bJohnson','511111111','johns$1','Brandy','Johnson','bjohnson@gmail.com','123-456-6789','123-456-6789',NULL,'453 Royal Sreet',NULL,'Raleigh','North Carolina','28241','1999-09-06','f'),('ctaylor','5158791265','taylo$23','Carol','Taylor','taylor23@gmail.com','111-111-1111',NULL,NULL,'123 Shanon Street',NULL,'New York','New York','11111','1994-10-12','f'),('elmosworld','111311111','yea','Elmo','Clash','eclash@gmail.com','980-111-1111',NULL,NULL,'123 Sesame Street',NULL,'New York City','New York','10001','1972-02-03','m'),('erobin','311111111','Elisabeth','Elisabeth','Robinson','erobin@gmail.com','453-678-9081',NULL,NULL,'123 Freedom Street',NULL,'Morrisville','North Carolina','27541','2000-12-01','f'),('hela','211111111','truevillian','Cate','Blanchett','cblanch@gmail.com','111-111-0899',NULL,NULL,'1834  Ingram Road',NULL,'Greensboro','North Carolina','27406','1969-05-14','f'),('jacksepticeye','111141111','septic','Sean','McLoughlin','jmclo@gmail.com','111-111-1555',NULL,NULL,'123 Bow Street',NULL,'Boston','Massachusetts','34321','1990-02-07','m'),('ladiesman217','111111111','shia','Sam','Witwicky','samw@gmail.com','111-111-1111',NULL,NULL,'123 Sesame Street',NULL,'New York','New York','11111','1985-01-01','m'),('lebeouf','111161111','shia','Shia','LeBeouf','slebeouf@gmail.com','111-124-1111',NULL,NULL,'123 Quriky Street',NULL,'New York','New York','11111','1986-06-11','m'),('lopez','111011111','flygirl','Jennifer','Lopez','jlopez@gmail.com','980-176-1111',NULL,NULL,'123 Castle Hill',NULL,'New York City','New York','12128','1969-07-24','f'),('lwhite','111171111','white','Lori','White','lwhite@gmail.com','111-111-1175',NULL,NULL,'123 Boggle Street',NULL,'New York','New York','10011','1995-01-24','f'),('mitchell','789111111','Mitshell@2','Anna','Mitchell','Mitchell@gmail.com','234-567-8910',NULL,NULL,'123 Barton Street',NULL,'Cary','North Carolina','25711','1995-01-01','m'),('parkeranna','611111111','aParker@23','Anna','Parket','parkerAnna@gmail.com','1111111111',NULL,NULL,'123 Sesame Street',NULL,'New York','New York','11111','1985-04-01','f'),('rosie','111181111','civilrights','Rosa','Parks','rparks@gmail.com','111-111-7986',NULL,NULL,'123 Musical Lane',NULL,'Detroit','Michigan','22111','1934-01-01','f'),('sliam','111151111','cars','Sean','Liam','seanl@gmail.com','111-134-1111',NULL,NULL,'123 Quick Street',NULL,'New York','New York','11111','2000-01-26','m'),('therock','111112111','therock','Dwayne','Johnson','therock@gmail.com','121-111-1111',NULL,NULL,'124 Sesame Street',NULL,'New York','New York','11111','1985-08-12','m'),('wrightA','110111111','wirght@1','Andrew','Wright','Awright@gmail.com','451-905-1111',NULL,NULL,'123 University Street',NULL,'Charlotte','North Carolina','28261','2000-08-11','m');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vehicle`
--

DROP TABLE IF EXISTS `Vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehicle` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehicle`
--

LOCK TABLES `Vehicle` WRITE;
/*!40000 ALTER TABLE `Vehicle` DISABLE KEYS */;
INSERT INTO `Vehicle` VALUES (1,2018,'Toyota','Corolla'),(2,1999,'Toyota','Corolla'),(3,2017,'Toyota','Corolla'),(4,2016,'Toyota','Corolla'),(5,2015,'Toyota','Corolla'),(6,2014,'Toyota','Corolla'),(7,2013,'Toyota','Corolla'),(8,2012,'Toyota','Corolla'),(9,2011,'Toyota','Corolla'),(10,2010,'Toyota','Corolla'),(11,2009,'Toyota','Corolla'),(12,2008,'Toyota','Corolla'),(13,2007,'Toyota','Corolla'),(14,2006,'Toyota','Corolla'),(15,2005,'Toyota','Corolla'),(16,2004,'Toyota','Corolla'),(17,2003,'Toyota','Corolla'),(18,2002,'Toyota','Corolla'),(19,2001,'Toyota','Corolla'),(20,2000,'Toyota','Corolla'),(21,2018,'Dodge','Durango'),(22,2017,'Dodge','Durango'),(23,2016,'Dodge','Durango'),(24,2015,'Dodge','Durango'),(25,2014,'Dodge','Durango'),(26,2013,'Dodge','Durango'),(27,2012,'Dodge','Durango'),(28,2011,'Dodge','Durango'),(29,2010,'Dodge','Durango'),(30,2009,'Ford','F-150'),(31,2008,'Ford','F-150'),(32,2007,'Ford','F-150'),(33,2006,'Ford','F-150'),(34,2005,'Ford','F-150'),(35,2004,'Ford','F-150'),(36,2003,'Ford','F-150'),(37,2002,'Ford','F-150'),(38,2001,'Ford','F-150'),(39,2000,'Ford','F-150'),(40,1999,'Toyota','Corolla'),(41,2017,'Toyota','Corolla'),(42,2016,'Toyota','Corolla'),(43,2015,'Toyota','Corolla'),(44,2014,'Toyota','Corolla'),(45,2013,'Toyota','Corolla'),(46,2012,'Toyota','Corolla'),(47,2011,'Toyota','Corolla'),(48,2010,'Toyota','Corolla'),(49,2009,'Toyota','Corolla'),(50,2008,'Toyota','Corolla'),(51,2007,'Toyota','Corolla'),(52,2006,'Toyota','Corolla'),(53,2005,'Toyota','Corolla'),(54,2004,'Toyota','Corolla'),(55,2003,'Toyota','Corolla'),(56,2002,'Toyota','Corolla'),(57,2001,'Toyota','Corolla'),(58,2000,'Toyota','Corolla'),(59,2018,'Dodge','Durango'),(60,2017,'Dodge','Durango'),(61,2016,'Dodge','Durango'),(62,2015,'Dodge','Durango'),(63,2014,'Dodge','Durango'),(64,2013,'Dodge','Durango'),(65,2012,'Dodge','Durango'),(66,2011,'Dodge','Durango'),(67,2010,'Dodge','Durango'),(68,2009,'Ford','F-150'),(69,2008,'Ford','F-150'),(70,2007,'Ford','F-150'),(71,2006,'Ford','F-150'),(72,2005,'Ford','F-150'),(73,2004,'Ford','F-150'),(74,2003,'Ford','F-150'),(75,2002,'Ford','F-150'),(76,2001,'Ford','F-150'),(77,2000,'Ford','F-150');
/*!40000 ALTER TABLE `Vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vehicle_History`
--

DROP TABLE IF EXISTS `Vehicle_History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehicle_History` (
  `vehicle_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `martial_status` varchar(255) NOT NULL,
  `highest_level_of_education` varchar(255) NOT NULL,
  `employment_status` varchar(255) NOT NULL,
  `residency` varchar(255) NOT NULL,
  `us_license_status` varchar(255) NOT NULL,
  `age_first_license` int(11) NOT NULL,
  `claims` tinyint(1) NOT NULL,
  `violations` tinyint(1) NOT NULL,
  `years_licensed` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_history_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Vehicle_History_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehicle_History`
--

LOCK TABLES `Vehicle_History` WRITE;
/*!40000 ALTER TABLE `Vehicle_History` DISABLE KEYS */;
INSERT INTO `Vehicle_History` VALUES (1,'therock','UnMarried','UnderGraduate','Employed','Permanent','Active',20,0,0,8),(2,'alien','Married','UnderGraduate','SelfEmployed','Permanent','Expired',22,0,0,9),(3,'erobin','UnMarried','UnderGraduate','Employed','Migrant','Active',24,0,0,8),(4,'bJohnson','Married','Graduate','Employed','Migrant','Active',22,0,0,8),(5,'parkeranna','UnMarried','UnderGraduate','SelfEmployed','Permanent','Expired',23,0,0,10),(6,'mitchell','Married','UnderGraduate','Employed','Migrant','Active',24,0,0,8),(7,'elmosworld','UnMarried','UnderGraduate','Employed','Permanent','Active',20,0,0,13),(8,'jacksepticeye','UnMarried','UnderGraduate','Employed','Permanent','Active',20,0,0,12),(9,'sliam','Married','UnderGraduate','SelfEmployed','Permanent','Active',22,0,0,9),(10,'lebeouf','Married','Graduate','Employed','Permanent','Active',22,0,0,8),(11,'lwhite','Married','UnderGraduate','Employed','Migrant','Expired',20,0,0,7),(12,'rosie','UnMarried','UnderGraduate','Employed','Permanent','Active',25,0,0,8),(13,'lopez','Married','UnderGraduate','SelfEmployed','Permanent','Active',23,0,0,5),(14,'ascott','UnMarried','UnderGraduate','Employed','Migrant','Expired',20,0,0,3),(15,'aJackson','Married','UnderGraduate','Employed','Permanent','Active',21,0,0,8),(16,'aRobonson','UnMarried','UnderGraduate','Employed','Migrant','Expired',21,0,0,4),(17,'ctaylor','UnMarried','UnderGraduate','Employed','Permanent','Active',22,0,0,6),(18,'hela','Married','UnderGraduate','Employed','Migrant','Active',25,0,0,8),(19,'ladiesman217','UnMarried','Graduate','SelfEmployed','Permanent','Expired',19,0,0,9),(20,'wrightA','Married','UnderGraduate','Employed','Permanent','Active',26,0,0,8);
/*!40000 ALTER TABLE `Vehicle_History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vehicle_Insurance_Policy`
--

DROP TABLE IF EXISTS `Vehicle_Insurance_Policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehicle_Insurance_Policy` (
  `policy_id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `liability_per_person` double DEFAULT NULL,
  `liability_per_accident` double DEFAULT NULL,
  `liability_property_damage` double DEFAULT NULL,
  `uninsured_motorist_per_person` double DEFAULT NULL,
  `uninsured_motorist_per_accident` double DEFAULT NULL,
  `uninsured_motorist_property_damage` double DEFAULT NULL,
  `underinsured_motorist_per_person` double DEFAULT NULL,
  `underinsured_motorist_per_accident` double DEFAULT NULL,
  `medical_payments` double DEFAULT NULL,
  `comprehensive` double DEFAULT NULL,
  `collision` double DEFAULT NULL,
  `extended_transportation_expenses` double DEFAULT NULL,
  `roadside` double DEFAULT NULL,
  `premium_monthly_rate` double NOT NULL,
  `premium_yearly_rate` double NOT NULL,
  PRIMARY KEY (`policy_id`,`company`),
  KEY `company` (`company`),
  CONSTRAINT `Vehicle_Insurance_Policy_ibfk_1` FOREIGN KEY (`company`) REFERENCES `Company` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehicle_Insurance_Policy`
--

LOCK TABLES `Vehicle_Insurance_Policy` WRITE;
/*!40000 ALTER TABLE `Vehicle_Insurance_Policy` DISABLE KEYS */;
INSERT INTO `Vehicle_Insurance_Policy` VALUES (1,'Pegram',25000,35000,10000,10000,15000,12000,16000,20000,12000,1000,20000,2000,10000,100,1200),(2,'Geico',30000,100000,20000,12000,16500,12500,16000,20000,12500,1000,21000,1000,12000,83.33,1000),(3,'Allstate',50000,60000,50000,12000,17000,14000,18000,25000,14000,1000,23000,1500,13000,131.25,1575),(4,'Progressive',35000,150000,10000,15000,17000,15000,20000,22000,25000,1200,25000,1400,1400,103,1243),(5,'State Farm',60000,200000,60000,17000,18000,16000,22000,23000,70000,1500,30000,1600,1500,110,1320);
/*!40000 ALTER TABLE `Vehicle_Insurance_Policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vehicle_Ownership`
--

DROP TABLE IF EXISTS `Vehicle_Ownership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehicle_Ownership` (
  `ownership_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `primary_use` varchar(255) NOT NULL,
  `ownership` varchar(255) NOT NULL,
  PRIMARY KEY (`ownership_id`),
  KEY `vehicle_id` (`vehicle_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Vehicle_Ownership_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `Vehicle` (`vehicle_id`),
  CONSTRAINT `Vehicle_Ownership_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `User` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehicle_Ownership`
--

LOCK TABLES `Vehicle_Ownership` WRITE;
/*!40000 ALTER TABLE `Vehicle_Ownership` DISABLE KEYS */;
INSERT INTO `Vehicle_Ownership` VALUES (1,'therock',1,'leisure','Own'),(2,'alien',5,'leisure','Lease'),(3,'erobin',24,'Commute less than 10 miles','Own'),(4,'bJohnson',3,'leisure','Own'),(5,'parkeranna',38,'Commute more than 10 miles','Lease'),(6,'mitchell',39,'Commute less than 10 miles','Lease'),(7,'elmosworld',16,'leisure','Own'),(8,'jacksepticeye',30,'Commute more than 10 miles','Lease'),(9,'sliam',32,'leisure','Lease'),(10,'lebeouf',11,'Commute more than 10 miles','Own'),(11,'lwhite',25,'Commute more than 10 miles','Lease'),(12,'rosie',26,'leisure','Lease'),(13,'lopez',27,'leisure','Own'),(14,'wrightA',16,'leisure','Own'),(15,'ascott',31,'Commute more than 10 miles','Lease'),(16,'aJackson',33,'leisure','Lease'),(17,'aRobonson',10,'Commute more than 10 miles','Own'),(18,'ctaylor',15,'Commute more than 10 miles','Lease'),(19,'hela',29,'leisure','Lease'),(20,'ladiesman217',22,'leisure','Own');
/*!40000 ALTER TABLE `Vehicle_Ownership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'unccfall2018dbproject'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-23 14:02:27
